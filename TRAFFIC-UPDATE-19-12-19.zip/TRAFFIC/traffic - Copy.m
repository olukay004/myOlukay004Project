% Define Total Cars in Simulation
total_cars = 40;

wing(1) = 'W';
wing(2) = 'W';
wing(3) = 'W';
wing(4) = 'W';
wing(5) = 'W';
wing(6) = 'W';
wing(7) = 'W';
wing(8) = 'W';
wing(9) = 'W';
wing(10) = 'W';
wing(11) = 'S';
wing(12) = 'S';
wing(13) = 'S';
wing(14) = 'S';
wing(15) = 'S';
wing(16) = 'S';
wing(17) = 'S';
wing(18) = 'S';
wing(19) = 'S';
wing(20) = 'S';
wing(21) = 'E';
wing(22) = 'E';
wing(23) = 'E';
wing(24) = 'E';
wing(25) = 'E';
wing(26) = 'E';
wing(27) = 'E';
wing(28) = 'E';
wing(29) = 'E';
wing(30) = 'E';
wing(31) = 'N';
wing(32) = 'N';
wing(33) = 'N';
wing(34) = 'N';
wing(35) = 'N';
wing(36) = 'N';
wing(37) = 'N';
wing(38) = 'N';
wing(39) = 'N';
wing(40) = 'N';

for k = 1:total_cars
   if wing(k)=='W' 
   randvar = randi([0 1],1,1);
   curved(k) = randvar;
   elseif wing(k)=='S' 
   randvar = randi([0 1],1,1);
   curved(k) = randvar;
   elseif wing(k)=='E' 
   randvar = randi([0 1],1,1);
   curved(k) = randvar;
   elseif wing(k)=='N' 
   curved(31) = 1;
   curved(32) = 0;
   curved(33) = 0;
   curved(34) = 0;
   curved(35) = 0;
   curved(36) = 0;
   curved(37) = 0;
   curved(38) = 0;
   curved(39) = 0;
   curved(40) = 0;
   end 
end

% Create Runway
rw_x = [55, 165, 275, 385, 495, 605, 715, 825, 935, 945];
rw_y = [500, 500, 500, 500, 500, 500, 500, 500, 500, 500];

rw_y2 = [95, 165, 275, 385, 495, 605, 715, 825, 825, 905];
rw_x2 = [500, 500, 500, 500, 500, 500, 500, 500, 500, 500];


% Draw initial figure
g = figure;
g.Position = [150,50,1100,630];

set(gcf,'Renderer','OpenGL');
% Horizontal Runway
h = plot(rw_x,rw_y,'s','MarkerSize',90,'MarkerFaceColor','w','MarkerEdgeColor','w');
title('SMART TRAFFIC SIMULATION')

hold on
% Vertical Runway
h2 = plot(rw_x2,rw_y2,'s','MarkerSize',90,'MarkerFaceColor','w','MarkerEdgeColor','w');

hold on
% Create Junction
h4 = plot(500,500,'s','MarkerSize',90,'MarkerFaceColor','k','MarkerEdgeColor','b');

hold on

% Create Traffic Lights
TL1= plot(430,620,'o','MarkerSize',10,'MarkerFaceColor','r','MarkerEdgeColor','k');
TL3= plot(570,380,'o','MarkerSize',10,'MarkerFaceColor','r','MarkerEdgeColor','k');
TL2= plot(430,380,'o','MarkerSize',10,'MarkerFaceColor','r','MarkerEdgeColor','k');
TL4= plot(570,620,'o','MarkerSize',10,'MarkerFaceColor','r','MarkerEdgeColor','k');

hold on

% Create Horizontal Runway lines
for k = 1:499
rl_x(k) = k * 2;
rl_y(k) = 500;
end

% Create Vertical Runway lines
for k = 1:199
rl_x2(k) = 500;
rl_y2(k) = k * 5;
end

y2 = [95, 165, 275, 385, 495, 605, 715, 825, 825, 905];
x2 = [500, 500, 500, 500, 500, 500, 500, 500, 500, 500];

% Horizontal Runway Line
rl1= plot(rl_x,rl_y,'s','MarkerSize',2,'MarkerFaceColor','k','MarkerEdgeColor','k');

% Vertical Runway Line
rl2= plot(rl_x2,rl_y2,'s','MarkerSize',2,'MarkerFaceColor','k','MarkerEdgeColor','k');


% Create X-position for Cars
for k = 1:total_cars
   if wing(k)=='W' 
   h3(k) = plot(40,550,'s','MarkerSize',30,'MarkerFaceColor','b','MarkerEdgeColor','k');
   elseif wing(k)=='S'
   h3(k) = plot(470,40,'s','MarkerSize',30,'MarkerFaceColor','b','MarkerEdgeColor','k');
   elseif wing(k)=='E'
   h3(k) = plot(960,450,'s','MarkerSize',30,'MarkerFaceColor','b','MarkerEdgeColor','k');
   elseif wing(k)=='N'
   h3(k) = plot(530,990,'s','MarkerSize',30,'MarkerFaceColor','b','MarkerEdgeColor','k');
   end 
end

grid on
grid minor
ax = gca;
ax.GridColor = 'r';  % [R, G, B]
ax.Color=[0.5 0.5 0.5 0.3];
set(gca,'XTickLabel',[], 'YTickLabel', [])
set(h,'EraseMode','normal');
xlim([0,1000]);
ylim([0,1000]);

% Animation Loop
i = 1;



% Create X OR Y position for  Populated Cars
for k = 1:total_cars
    if wing(k) == 'W'
        x(k) = 40 - (40*k);
    elseif wing(k) == 'S'
        x(k) = 440 - (40*k);
    elseif wing(k) == 'E'
        x(k) = 160 + (40*k);
    elseif wing(k) == 'N'
        x(k) = -240 + (40*k);
    end
end

% Create Speed for Cars
for k = 1:total_cars
if wing(k) == 'W'
    speed(k) = 40;
elseif wing(k) == 'S'
    speed(k) = 40;
elseif wing(k) == 'E'
    speed(k) = -40;    
elseif wing(k) == 'N'
    speed(k) = -40;
end
end

%No. Of Queued Cars
queued_cars = 0;

%No. Of Cars in Delay : W,S,E,N
delay_W = 0;
delay_S = 0;
delay_E = 0;
delay_N = 0;


ann1 = annotation('textbox', [0.75,0.82,0.1,0.1],...
           'String', delay_W);
ann2 = annotation('textbox', [0.75,0.82,0.1,0.1],...
           'String', delay_N);
ann3 = annotation('textbox', [0.75,0.82,0.1,0.1],...
           'String', delay_E);
ann4 = annotation('textbox', [0.75,0.82,0.1,0.1],...
           'String', delay_S);


% While loop
while i<=110000
    
    % Update locations
    for k = 1:total_cars
        if wing(k)=='W' 
            set(h3(k),'XData',x(k));
            %get Current Car Position
            current_car_pos(k) = get(h3(k),'XData');
        elseif wing(k)=='S' 
            set(h3(k),'YData',x(k));
            %get Current Car Position
            current_car_pos(k) = get(h3(k),'YData');
        elseif wing(k)=='E' 
            set(h3(k),'XData',x(k));
            %get Current Car Position
            current_car_pos(k) = get(h3(k),'XData');
        elseif wing(k)=='N' 
            set(h3(k),'YData',x(k));
            %get Current Car Position
            current_car_pos(k) = get(h3(k),'YData');
        
            
        end 
    end
    
  
    % Draw On Screen
    drawnow;
    
    % Advance Car locations for each car
    
    for k = 1:total_cars
        
           if wing(k)=='W'
               next_pos = current_car_pos(k)+speed(k);
               
               if k == 1 || k == 11 || k == 21 || k == 31
                   if next_pos < 425 || next_pos > 585; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if next_pos < current_car_pos(k-1)-40 && next_pos < 425 || next_pos > 585; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
           elseif wing(k)=='S'
               next_pos = current_car_pos(k)+speed(k);
               if k == 1 || k == 11 || k == 21 || k == 31
                   if next_pos < 375 || next_pos > 535; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if next_pos < current_car_pos(k-1)-80 && next_pos < 375 || next_pos > 535; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
           elseif wing(k)=='E'
               next_pos = current_car_pos(k)+speed(k);
               if k == 1 || k == 11 || k == 21 || k == 31
                   if next_pos > 575 || next_pos < 415; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if next_pos > current_car_pos(k-1)+40 && next_pos > 575 || next_pos < 415; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
           elseif wing(k)=='N'
               next_pos = current_car_pos(k)+speed(k);
               if k == 1 || k == 11 || k == 21 || k == 31
                   if next_pos > 625 || next_pos < 465; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if next_pos > current_car_pos(k-1)+80 && next_pos > 625 || next_pos < 465; 
                       x(k) = x(k) + speed(k); 
                   end
               end    
               
           end
           
           
           %%%%%%%% JUNCTION ALGORITHM
           
           next_pos = current_car_pos(k)+speed(k);
           if wing(k)=='W'
           if next_pos >= 425; 
               if queued_cars == 0; x(k) = x(k) + 5; queued_cars = 1;set(TL1,'MarkerfaceColor','g');queued_car = k;
               elseif queued_cars == 1 && queued_car == k; x(k) = x(k) + 5;
               end 
           end
           if next_pos > 585; 
               queued_cars = 0;set(TL1,'MarkerfaceColor','r'); 
           end
           
           %For curved crossings
           if curved(k) == 1;
           if next_pos > 570; wing(k) = 'N';speed(k) = -40;end
           end
           end
           
           if wing(k)=='S'
           if next_pos >= 375; 
               if queued_cars == 0; x(k) = x(k) + 5; queued_cars = 1;set(TL2,'MarkerfaceColor','g');queued_car = k;
               elseif queued_cars == 1 && queued_car == k; x(k) = x(k) + 5;
               end 
           end
           if next_pos > 535; 
               queued_cars = 0;set(TL2,'MarkerfaceColor','r');
           end
           
           %For curved crossings
           if k == 11;
           if next_pos > 545; wing(k) = 'E';speed(k) = 40;end
           end
           end
           
           if wing(k)=='E'
           if next_pos <= 575; 
               if queued_cars == 0; x(k) = x(k) - 5; queued_cars = 5;set(TL3,'MarkerfaceColor','g');queued_car = k;
               elseif queued_cars == 1 && queued_car == k; x(k) = x(k) - 5;
               end 
           end
           if next_pos < 415; 
               queued_cars = 0;set(TL3,'MarkerfaceColor','r'); 
           end
           
           %For curved crossings
           if curved(k) == 1;
           if next_pos < 435; wing(k) = 'S';speed(k) = 40;end
           end
           end
           
           if wing(k)=='N'
           if next_pos <= 625; 
               if queued_cars == 0; x(k) = x(k) - 5; queued_cars = 1;set(TL4,'MarkerfaceColor','g');queued_car = k;
               elseif queued_cars == 1 && queued_car == k; x(k) = x(k) - 5;
               end 
           end
           if next_pos < 465; 
               queued_cars = 0;set(TL4,'MarkerfaceColor','r'); 
           end
           
           %For curved crossings
           if curved(k) == 1;
           if next_pos < 450; wing(k) = 'W';speed(k) = -40;end
           end
           end
           
           
    end
    
     delay_W = 0;
     delay_N = 0;
     delay_E = 0;
     delay_S = 0;
    % Check number of delayed cars
     for k = 1:total_cars
           if wing(k)=='W'
               if current_car_pos(k)<= 425; delay_W=delay_W+1; end
           end 
           if wing(k)=='N'
               if current_car_pos(k)>= 625; delay_N=delay_N+1; end
           end 
           if wing(k)=='E'
               if current_car_pos(k)>= 575; delay_E=delay_E+1; end
           end 
           if wing(k)=='S'
               if current_car_pos(k)<= 375; delay_S=delay_S+1; end
           end 
     end
     
     
    clmo(ann1)
    ann1 = annotation('textbox', [0.42,0.54,0.1,0.1],...
           'String', delay_W);
    clmo(ann2)
    ann2 = annotation('textbox', [0.59,0.54,0.1,0.1],...
           'String', delay_N);
    clmo(ann3)
    ann3 = annotation('textbox', [0.59,0.33,0.1,0.1],...
           'String', delay_E);
    clmo(ann4)
    ann4 = annotation('textbox', [0.42,0.33,0.1,0.1],...
           'String', delay_S);
    
    
    % Update iterations
    i = i+1;
   
    
end
