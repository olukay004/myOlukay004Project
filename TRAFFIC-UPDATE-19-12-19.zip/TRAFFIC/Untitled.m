% Define Total Cars in Simulation
total_cars = 16;

wing(1) = 'W';
wing(2) = 'W';
wing(3) = 'W';
wing(4) = 'W';
wing(5) = 'S';
wing(6) = 'S';
wing(7) = 'S';
wing(8) = 'S';
wing(9) = 'N';
wing(10) = 'N';
wing(11) = 'N';
wing(12) = 'N';
wing(13) = 'E';
wing(14) = 'E';
wing(15) = 'E';
wing(16) = 'E';

% Create Runway
x = [55, 165, 275, 385, 495, 605, 715, 825, 935, 945];
y = [500, 500, 500, 500, 500, 500, 500, 500, 500, 500];

y2 = [95, 165, 275, 385, 495, 605, 715, 825, 825, 905];
x2 = [500, 500, 500, 500, 500, 500, 500, 500, 500, 500];

% Draw initial figure
g = figure;
g.Position = [150,50,1100,630];

set(gcf,'Renderer','OpenGL');
h = plot(x,y,'s','MarkerSize',90,'MarkerFaceColor','w','MarkerEdgeColor','w');
title('SMART TRAFFIC SIMULATION')

hold on
h2 = plot(x2,y2,'s','MarkerSize',90,'MarkerFaceColor','w','MarkerEdgeColor','w');

hold on
h4 = plot(500,500,'s','MarkerSize',90,'MarkerFaceColor','k','MarkerEdgeColor','b');

hold on

% Create X-position for Cars
for k = 1:total_cars
   if wing(k)=='W' 
   h3(k) = plot(40,550,'s','MarkerSize',30,'MarkerFaceColor','r','MarkerEdgeColor','k');
   elseif wing(k)=='S'
   h3(k) = plot(470,40,'s','MarkerSize',30,'MarkerFaceColor','b','MarkerEdgeColor','k');
   elseif wing(k)=='E'
   h3(k) = plot(960,450,'s','MarkerSize',30,'MarkerFaceColor','g','MarkerEdgeColor','k');
   elseif wing(k)=='N'
   h3(k) = plot(530,990,'s','MarkerSize',30,'MarkerFaceColor','w','MarkerEdgeColor','k');
   end 
end

grid on
grid minor
ax = gca;
ax.GridColor = 'r';  % [R, G, B]
ax.Color=[0.5 0.5 0.5 0.3];
set(gca,'XTickLabel',[], 'YTickLabel', [])
set(h,'EraseMode','normal');
xlim([0,1000]);
ylim([0,1000]);

% Animation Loop
i = 1;

% Create X OR Y position for Cars
for k = 1:total_cars
    if wing(k) == 'W'
    x(k) = 40 -(40*k);
    end
end

% Create Speed for Cars
for k = 1:total_cars
if wing(k) == 'W'
    speed(k) = 1;
elseif wing(k) == 'S'
    speed(k) = 0.8;
elseif wing(k) == 'E'
    speed(k) = 0.7;    
elseif wing(k) == 'N'
    speed(k) = 0.6;
end
end



% While loop
while i<=110000
    
    % Update locations
    for k = 1:total_cars
        if wing(k)=='W' 
            set(h3(k),'XData',x(k));
            %get Current Car Position
            current_car_pos(k) = get(h3(k),'XData');
        elseif wing(k)=='S'
            set(h3(k),'YData',x(k));
            %get Current Car Position
            current_car_pos(k) = get(h3(k),'YData');
        elseif wing(k)=='E'
            set(h3(k),'XData',x(k));
            %get Current Car Position
            current_car_pos(k) = get(h3(k),'XData');
        elseif wing(k)=='N'
            set(h3(k),'YData',x(k));
            %get Current Car Position
            current_car_pos(k) = get(h3(k),'YData');
        end 
    end
    
    
    
    % Draw On Screen
    drawnow;
    
    % Advance Car locations for each car
    
    for k = 1:total_cars
         % Check if no car is directly in front
       for car = 1:total_cars
           next_pos = current_car_pos(k)+speed(k);
           if wing(k)=='W'
               current_car_pos2(car) = get(h3(car),'XData');
               current_junc_pos =  get(h4,'XData');
           elseif wing(k)=='S'
               current_car_pos2(car) = get(h3(car),'YData');
               current_junc_pos =  get(h4,'YData');
           end
           
           if next_pos < current_junc_pos-90
               
           if car == k
               x(k) = x(k);
           elseif next_pos < current_car_pos2(car)-40  
               x(k) = x(k) + speed(k);
           elseif car > k
               x(k) = x(k) + speed(k);
           else
               x(k) = x(k);
           end
           
           
           elseif next_pos >= current_junc_pos-90
               for car = 1:total_cars
                   current_car_pos2_x(car) = get(h3(k),'XData');
                   current_car_pos2_y(car) = get(h3(k),'YData');
                   
                   
                   if car == k
                       x(k) = x(k) + speed(k);
                   elseif ge(current_car_pos2_x(car),460) && le(current_car_pos2_x(car),580) && ge(current_car_pos2_y(car),380) && le(current_car_pos2_y(car),620) 
                   
                   elseif car > k
                       x(k) = x(k) + speed(k);
                   else
                       x(k) = x(k) + speed(k);
                   end
                   
               end
           end
           
       end
       
    end
    
    
    % Update iterations
    i = i+1;
   
    
end
