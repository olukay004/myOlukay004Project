function varargout = TrafficGUI(varargin)
% TRAFFICGUI MATLAB code for TrafficGUI.fig
%      TRAFFICGUI, by itself, creates a new TRAFFICGUI or raises the existing
%      singleton*.
%
%      H = TRAFFICGUI returns the handle to a new TRAFFICGUI or the handle to
%      the existing singleton*.
%
%      TRAFFICGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TRAFFICGUI.M with the given input arguments.
%
%      TRAFFICGUI('Property','Value',...) creates a new TRAFFICGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before TrafficGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to TrafficGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help TrafficGUI

% Last Modified by GUIDE v2.5 29-May-2018 14:20:52

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @TrafficGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @TrafficGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before TrafficGUI is made visible.
function TrafficGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to TrafficGUI (see VARARGIN)

% Choose default command line output for TrafficGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes TrafficGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);



% --- Outputs from this function are returned to the command line.
function varargout = TrafficGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function SN_Callback(hObject, eventdata, handles)
% hObject    handle to SN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SN as text
%        str2double(get(hObject,'String')) returns contents of SN as a double


% --- Executes during object creation, after setting all properties.
function SN_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function SW_Callback(hObject, eventdata, handles)
% hObject    handle to SW (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SW as text
%        str2double(get(hObject,'String')) returns contents of SW as a double


% --- Executes during object creation, after setting all properties.
function SW_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SW (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function WE_Callback(hObject, eventdata, handles)
% hObject    handle to WE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of WE as text
%        str2double(get(hObject,'String')) returns contents of WE as a double


% --- Executes during object creation, after setting all properties.
function WE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to WE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function WN_Callback(hObject, eventdata, handles)
% hObject    handle to WN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of WN as text
%        str2double(get(hObject,'String')) returns contents of WN as a double


% --- Executes during object creation, after setting all properties.
function WN_CreateFcn(hObject, eventdata, handles)
% hObject    handle to WN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function NS_Callback(hObject, eventdata, handles)
% hObject    handle to NS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of NS as text
%        str2double(get(hObject,'String')) returns contents of NS as a double


% --- Executes during object creation, after setting all properties.
function NS_CreateFcn(hObject, eventdata, handles)
% hObject    handle to NS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function NE_Callback(hObject, eventdata, handles)
% hObject    handle to NE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of NE as text
%        str2double(get(hObject,'String')) returns contents of NE as a double


% --- Executes during object creation, after setting all properties.
function NE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to NE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EW_Callback(hObject, eventdata, handles)
% hObject    handle to EW (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EW as text
%        str2double(get(hObject,'String')) returns contents of EW as a double


% --- Executes during object creation, after setting all properties.
function EW_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EW (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ES_Callback(hObject, eventdata, handles)
% hObject    handle to ES (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ES as text
%        str2double(get(hObject,'String')) returns contents of ES as a double


% --- Executes during object creation, after setting all properties.
function ES_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ES (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function SE_Callback(hObject, eventdata, handles)
% hObject    handle to SE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SE as text
%        str2double(get(hObject,'String')) returns contents of SE as a double


% --- Executes during object creation, after setting all properties.
function SE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function WS_Callback(hObject, eventdata, handles)
% hObject    handle to WS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of WS as text
%        str2double(get(hObject,'String')) returns contents of WS as a double


% --- Executes during object creation, after setting all properties.
function WS_CreateFcn(hObject, eventdata, handles)
% hObject    handle to WS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function NW_Callback(hObject, eventdata, handles)
% hObject    handle to NW (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of NW as text
%        str2double(get(hObject,'String')) returns contents of NW as a double


% --- Executes during object creation, after setting all properties.
function NW_CreateFcn(hObject, eventdata, handles)
% hObject    handle to NW (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EN_Callback(hObject, eventdata, handles)
% hObject    handle to EN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EN as text
%        str2double(get(hObject,'String')) returns contents of EN as a double


% --- Executes during object creation, after setting all properties.
function EN_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2


% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3


% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton4


% --- Executes on button press in R_weN.
function R_weN_Callback(hObject, eventdata, handles)
% hObject    handle to R_weN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of R_weN


% --- Executes on button press in R_weY.
function R_weY_Callback(hObject, eventdata, handles)
% hObject    handle to R_weY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of R_weY
if get(hObject,'value')==1
    set(handles.R_snY,'value',0);
    set(handles.R_swY,'value',0);    
    set(handles.R_wnY,'value',0);
    set(handles.R_nsY,'value',0);
    set(handles.R_neY,'value',0);
    set(handles.R_ewY,'value',0);
    set(handles.R_esY,'value',0);
    
%     set(handles.R_snN,'value',0);
%     set(handles.R_swN,'value',0);
%     set(handles.R_weN,'value',0);
%     set(handles.R_wnN,'value',0);
%     set(handles.R_nsN,'value',0);
%     set(handles.R_neN,'value',0);
%     set(handles.R_ewN,'value',0);
%     set(handles.R_esN,'value',0);
end


% --- Executes on button press in R_swN.
function R_swN_Callback(hObject, eventdata, handles)
% hObject    handle to R_swN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of R_swN


% --- Executes on button press in R_swY.
function R_swY_Callback(hObject, eventdata, handles)
% hObject    handle to R_swY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of R_swY
if get(hObject,'value')==1
    set(handles.R_snY,'value',0);    
    set(handles.R_weY,'value',0);
    set(handles.R_wnY,'value',0);
    set(handles.R_nsY,'value',0);
    set(handles.R_neY,'value',0);
    set(handles.R_ewY,'value',0);
    set(handles.R_esY,'value',0);
    
%     set(handles.R_snN,'value',0);
%     set(handles.R_swN,'value',0);
%     set(handles.R_weN,'value',0);
%     set(handles.R_wnN,'value',0);
%     set(handles.R_nsN,'value',0);
%     set(handles.R_neN,'value',0);
%     set(handles.R_ewN,'value',0);
%     set(handles.R_esN,'value',0);
end


% --- Executes on button press in R_snN.
function R_snN_Callback(hObject, eventdata, handles)
% hObject    handle to R_snN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of R_snN


% --- Executes on button press in R_snY.
function R_snY_Callback(hObject, eventdata, handles)
% hObject    handle to R_snY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of R_snY
if get(hObject,'value')==1
    set(handles.R_swY,'value',0);
    set(handles.R_weY,'value',0);
    set(handles.R_wnY,'value',0);
    set(handles.R_nsY,'value',0);
    set(handles.R_neY,'value',0);
    set(handles.R_ewY,'value',0);
    set(handles.R_esY,'value',0);
    
%     set(handles.R_snN,'value',0);
%     set(handles.R_swN,'value',0);
%     set(handles.R_weN,'value',0);
%     set(handles.R_wnN,'value',0);
%     set(handles.R_nsN,'value',0);
%     set(handles.R_neN,'value',0);
%     set(handles.R_ewN,'value',0);
%     set(handles.R_esN,'value',0);
end




% --- Executes on button press in R_wnN.
function R_wnN_Callback(hObject, eventdata, handles)
% hObject    handle to R_wnN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of R_wnN




% --- Executes on button press in R_wnY.
function R_wnY_Callback(hObject, eventdata, handles)
% hObject    handle to R_wnY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of R_wnY

if get(hObject,'value')==1
    set(handles.R_snY,'value',0);
    set(handles.R_swY,'value',0);
    set(handles.R_weY,'value',0);    
    set(handles.R_nsY,'value',0);
    set(handles.R_neY,'value',0);
    set(handles.R_ewY,'value',0);
    set(handles.R_esY,'value',0);
    
%     set(handles.R_snN,'value',0);
%     set(handles.R_swN,'value',0);
%     set(handles.R_weN,'value',0);
%     set(handles.R_wnN,'value',0);
%     set(handles.R_nsN,'value',0);
%     set(handles.R_neN,'value',0);
%     set(handles.R_ewN,'value',0);
%     set(handles.R_esN,'value',0);
end



% --- Executes on button press in R_nsN.
function R_nsN_Callback(hObject, eventdata, handles)
% hObject    handle to R_nsN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of R_nsN


% --- Executes on button press in R_nsY.
function R_nsY_Callback(hObject, eventdata, handles)
% hObject    handle to R_nsY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of R_nsY

if get(hObject,'value')==1
    set(handles.R_snY,'value',0);
    set(handles.R_swY,'value',0);
    set(handles.R_weY,'value',0);
    set(handles.R_wnY,'value',0);    
    set(handles.R_neY,'value',0);
    set(handles.R_ewY,'value',0);
    set(handles.R_esY,'value',0);
    
%     set(handles.R_snN,'value',0);
%     set(handles.R_swN,'value',0);
%     set(handles.R_weN,'value',0);
%     set(handles.R_wnN,'value',0);
%     set(handles.R_nsN,'value',0);
%     set(handles.R_neN,'value',0);
%     set(handles.R_ewN,'value',0);
%     set(handles.R_esN,'value',0);
end



% --- Executes on button press in R_neN.
function R_neN_Callback(hObject, eventdata, handles)
% hObject    handle to R_neN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of R_neN


% --- Executes on button press in R_neY.
function R_neY_Callback(hObject, eventdata, handles)
% hObject    handle to R_neY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of R_neY

if get(hObject,'value')==1
    set(handles.R_snY,'value',0);
    set(handles.R_swY,'value',0);
    set(handles.R_weY,'value',0);
    set(handles.R_wnY,'value',0);
    set(handles.R_nsY,'value',0);    
    set(handles.R_ewY,'value',0);
    set(handles.R_esY,'value',0);
    
%     set(handles.R_snN,'value',0);
%     set(handles.R_swN,'value',0);
%     set(handles.R_weN,'value',0);
%     set(handles.R_wnN,'value',0);
%     set(handles.R_nsN,'value',0);
%     set(handles.R_neN,'value',0);
%     set(handles.R_ewN,'value',0);
%     set(handles.R_esN,'value',0);
end



% --- Executes on button press in R_ewN.
function R_ewN_Callback(hObject, eventdata, handles)
% hObject    handle to R_ewN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of R_ewN


% --- Executes on button press in R_ewY.
function R_ewY_Callback(hObject, eventdata, handles)
% hObject    handle to R_ewY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of R_ewY

if get(hObject,'value')==1
    set(handles.R_snY,'value',0);
    set(handles.R_swY,'value',0);
    set(handles.R_weY,'value',0);
    set(handles.R_wnY,'value',0);
    set(handles.R_nsY,'value',0);
    set(handles.R_neY,'value',0);    
    set(handles.R_esY,'value',0);
    
%     set(handles.R_snN,'value',0);
%     set(handles.R_swN,'value',0);
%     set(handles.R_weN,'value',0);
%     set(handles.R_wnN,'value',0);
%     set(handles.R_nsN,'value',0);
%     set(handles.R_neN,'value',0);
%     set(handles.R_ewN,'value',0);
%     set(handles.R_esN,'value',0);
end



% --- Executes on button press in R_esN.
function R_esN_Callback(hObject, eventdata, handles)
% hObject    handle to R_esN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of R_esN


% --- Executes on button press in R_esY.
function R_esY_Callback(hObject, eventdata, handles)
% hObject    handle to R_esY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of R_esY
if get(hObject,'value')==1
    set(handles.R_snY,'value',0);
    set(handles.R_swY,'value',0);
    set(handles.R_weY,'value',0);
    set(handles.R_wnY,'value',0);
    set(handles.R_nsY,'value',0);
    set(handles.R_neY,'value',0);
    set(handles.R_ewY,'value',0);
        
%     set(handles.R_snN,'value',0);
%     set(handles.R_swN,'value',0);
%     set(handles.R_weN,'value',0);
%     set(handles.R_wnN,'value',0);
%     set(handles.R_nsN,'value',0);
%     set(handles.R_neN,'value',0);
%     set(handles.R_ewN,'value',0);
%     set(handles.R_esN,'value',0);
end



% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

TLD = readfis('TLD.fis');

sn = str2double(get(handles.SN,'String'));
sw = str2double(get(handles.SW,'String'));
% se = str2double(get(handles.SE,'String'));
we = str2double(get(handles.WE,'String'));
wn = str2double(get(handles.WN,'String'));
% ws = str2double(get(handles.WS,'String'));
ns = str2double(get(handles.NS,'String'));
ne = str2double(get(handles.NE,'String'));
% nw = str2double(get(handles.NW,'String'));
ew = str2double(get(handles.EW,'String'));
es = str2double(get(handles.ES,'String'));
% en = str2double(get(handles.EN,'String'));

X = [sn sw we wn ns ne ew es];



if X <= [20 20 20 20 20 20 20 20]
    
    y = evalfis(X,TLD);
    
    if y(:,1)<0.5
        set(handles.LA_SN,'String','Red');
    else
        set(handles.LA_SN,'String','Green');
    end    
      
    if y(:,2)<0.5
        set(handles.LA_SW,'String','Red');
    else
        set(handles.LA_SW,'String','Green');
    end
    
    if y(:,2)<0.5
        set(handles.LA_SE,'String','Red');
    else
        set(handles.LA_SE,'String','Green');
    end
    
    if y(:,3)<0.5
        set(handles.LA_WE,'String','Red');
    else
        set(handles.LA_WE,'String','Green');
    end
    
    if y(:,4)<0.5
        set(handles.LA_WN,'String','Red');
    else
        set(handles.LA_WN,'String','Green');
    end
    
    if y(:,4)<0.5
        set(handles.LA_WS,'String','Red');
    else
        set(handles.LA_WS,'String','Green');
    end
    
    if y(:,5)<0.5
        set(handles.LA_NS,'String','Red');
    else
        set(handles.LA_NS,'String','Green');
    end
    
    if y(:,6)<0.5
        set(handles.LA_NE,'String','Red');
    else
        set(handles.LA_NE,'String','Green');
    end
    
    if y(:,6)<0.5
        set(handles.LA_NW,'String','Red');
    else
        set(handles.LA_NW,'String','Green');
    end
    
    if y(:,7)<0.5
        set(handles.LA_EW,'String','Red');
    else
        set(handles.LA_EW,'String','Green');
    end
    
    if y(:,8)<0.5
        set(handles.LA_ES,'String','Red');
    else
        set(handles.LA_ES,'String','Green');
    end
    
     if y(:,8)<0.5
        set(handles.LA_EN,'String','Red');
    else
        set(handles.LA_EN,'String','Green');
    end
    
    % Handling of Emergency    
    la_sn = get(handles.R_snY,'value');
    la_sw = get(handles.R_swY,'value');
    la_se = get(handles.R_swY,'value');
    la_we = get(handles.R_weY,'value');
    la_wn = get(handles.R_wnY,'value');
    la_ws = get(handles.R_wnY,'value');
    la_ns = get(handles.R_nsY,'value');
    la_ne = get(handles.R_neY,'value');
    la_nw = get(handles.R_neY,'value');
    la_ew = get(handles.R_ewY,'value');
    la_es = get(handles.R_esY,'value');
    la_en = get(handles.R_esY,'value');
    
    if la_sn==1        
        set(handles.LA_SN,'String','Green');
        set(handles.LA_SW,'String','Red');
        set(handles.LA_WE,'String','Red');
        set(handles.LA_WN,'String','Red');
        set(handles.LA_NS,'String','Red');
        set(handles.LA_NE,'String','Red');
        set(handles.LA_EW,'String','Red');
        set(handles.LA_ES,'String','Red');
    elseif la_sw == 1
        set(handles.LA_SN,'String','Red');
        set(handles.LA_SW,'String','Green');
        set(handles.LA_WE,'String','Red');
        set(handles.LA_WN,'String','Red');
        set(handles.LA_NS,'String','Red');
        set(handles.LA_NE,'String','Red');
        set(handles.LA_EW,'String','Red');
        set(handles.LA_ES,'String','Red');
    elseif la_we == 1
        set(handles.LA_SN,'String','Red');
        set(handles.LA_SW,'String','Red');
        set(handles.LA_WE,'String','Green');
        set(handles.LA_WN,'String','Red');
        set(handles.LA_NS,'String','Red');
        set(handles.LA_NE,'String','Red');
        set(handles.LA_EW,'String','Red');
        set(handles.LA_ES,'String','Red');
    elseif la_wn == 1
        set(handles.LA_SN,'String','Red');
        set(handles.LA_SW,'String','Red');
        set(handles.LA_WE,'String','Red');
        set(handles.LA_WN,'String','Green');
        set(handles.LA_NS,'String','Red');
        set(handles.LA_NE,'String','Red');
        set(handles.LA_EW,'String','Red');
        set(handles.LA_ES,'String','Red');
    elseif la_ns == 1
        set(handles.LA_SN,'String','Red');
        set(handles.LA_SW,'String','Red');
        set(handles.LA_WE,'String','Red');
        set(handles.LA_WN,'String','Red');
        set(handles.LA_NS,'String','Green');
        set(handles.LA_NE,'String','Red');
        set(handles.LA_EW,'String','Red');
        set(handles.LA_ES,'String','Red');
    elseif la_ne == 1
        set(handles.LA_SN,'String','Red');
        set(handles.LA_SW,'String','Red');
        set(handles.LA_WE,'String','Red');
        set(handles.LA_WN,'String','Red');
        set(handles.LA_NS,'String','Red');
        set(handles.LA_NE,'String','Green');
        set(handles.LA_EW,'String','Red');
        set(handles.LA_ES,'String','Red');
    elseif la_ew == 1
        set(handles.LA_SN,'String','Red');
        set(handles.LA_SW,'String','Red');
        set(handles.LA_WE,'String','Red');
        set(handles.LA_WN,'String','Red');
        set(handles.LA_NS,'String','Red');
        set(handles.LA_NE,'String','Red');
        set(handles.LA_EW,'String','Green');
        set(handles.LA_ES,'String','Red');
    elseif la_es == 1
        set(handles.LA_SN,'String','Red');
        set(handles.LA_SW,'String','Red');
        set(handles.LA_WE,'String','Red');
        set(handles.LA_WN,'String','Red');
        set(handles.LA_NS,'String','Red');
        set(handles.LA_NE,'String','Red');
        set(handles.LA_EW,'String','Red');
        set(handles.LA_ES,'String','Green');        
    end
    
    
    
else
    msgbox('Input cars out of Range');
end

msgbox('Done');





% --- Executes during object creation, after setting all properties.
function LA_SN_CreateFcn(hObject, eventdata, handles)
% hObject    handle to LA_SN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
