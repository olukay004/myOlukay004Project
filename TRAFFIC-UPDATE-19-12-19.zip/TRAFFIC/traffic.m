% Define Total Cars in Simulation
total_cars = 80;

wing(1) = 'W'; wing(41) = 'w';
wing(2) = 'W'; wing(42) = 'w';
wing(3) = 'W'; wing(43) = 'w';
wing(4) = 'W'; wing(44) = 'w';
wing(5) = 'W'; wing(45) = 'w';
wing(6) = 'W'; wing(46) = 'w';
wing(7) = 'W'; wing(47) = 'w';
wing(8) = 'W'; wing(48) = 'w';
wing(9) = 'W'; wing(49) = 'w';
wing(10) = 'W'; wing(50) = 'w';
wing(11) = 'S'; wing(51) = 's';
wing(12) = 'S'; wing(52) = 's';
wing(13) = 'S'; wing(53) = 's';
wing(14) = 'S'; wing(54) = 's';
wing(15) = 'S'; wing(55) = 's';
wing(16) = 'S'; wing(56) = 's';
wing(17) = 'S'; wing(57) = 's';
wing(18) = 'S'; wing(58) = 's';
wing(19) = 'S'; wing(59) = 's';
wing(20) = 'S'; wing(60) = 's';
wing(21) = 'E'; wing(61) = 'e';
wing(22) = 'E'; wing(62) = 'e';
wing(23) = 'E'; wing(63) = 'e';
wing(24) = 'E'; wing(64) = 'e';
wing(25) = 'E'; wing(65) = 'e';
wing(26) = 'E'; wing(66) = 'e';
wing(27) = 'E'; wing(67) = 'e';
wing(28) = 'E'; wing(68) = 'e';
wing(29) = 'E'; wing(69) = 'e';
wing(30) = 'E'; wing(70) = 'e';
wing(31) = 'N'; wing(71) = 'n';
wing(32) = 'N'; wing(72) = 'n';
wing(33) = 'N'; wing(73) = 'n';
wing(34) = 'N'; wing(74) = 'n';
wing(35) = 'N'; wing(75) = 'n';
wing(36) = 'N'; wing(76) = 'n';
wing(37) = 'N'; wing(77) = 'n';
wing(38) = 'N'; wing(78) = 'n';
wing(39) = 'N'; wing(79) = 'n';
wing(40) = 'N'; wing(80) = 'n';

for k = 1:total_cars
   if wing(k)=='W' 
   curved(1) = 1;
   curved(2) = 0;
   curved(3) = 0;
   curved(4) = 1;
   curved(5) = 0;
   curved(6) = 0;
   curved(7) = 1;
   curved(8) = 1;
   curved(9) = 0;
   curved(10) = 1;
   elseif wing(k)=='S' 
   curved(11) = 1;
   curved(12) = 0;
   curved(13) = 1;
   curved(14) = 0;
   curved(15) = 1;
   curved(16) = 0;
   curved(17) = 0;
   curved(18) = 1;
   curved(19) = 0;
   curved(20) = 0;
   elseif wing(k)=='E' 
   curved(21) = 1;
   curved(22) = 0;
   curved(23) = 0;
   curved(24) = 0;
   curved(25) = 0;
   curved(26) = 1;
   curved(27) = 1;
   curved(28) = 0;
   curved(29) = 1;
   curved(30) = 1;
   elseif wing(k)=='N' 
   curved(31) = 1;
   curved(32) = 1;
   curved(33) = 0;
   curved(34) = 1;
   curved(35) = 0;
   curved(36) = 0;
   curved(37) = 0;
   curved(38) = 0;
   curved(39) = 1;
   curved(40) = 0;
   elseif wing(k)=='w' 
   curved(k) = 2;
   elseif wing(k)=='s' 
   curved(k) = 2;
   elseif wing(k)=='e' 
   curved(k) = 2;
   elseif wing(k)=='n' 
   curved(k) = 2;
   end 
end


for k = 1:total_cars
    curvable(k) = 1;
end

for k = 1:total_cars
    color(k) = 'b';
    color(12) = 'r';
    color(4) = 'r';
    color(29) = 'r';
    color(43) = 'r';
    color(67) = 'r';
    color(73) = 'r';
end


% Create Runway
rw_x = [110, 165, 275, 385, 495, 605, 715, 800, 805, 890];
rw_y = [500, 500, 500, 500, 500, 500, 500, 500, 500, 500];

rw_y2 = [180, 200, 200, 385, 495, 605, 715, 805, 805, 820];
rw_x2 = [500, 500, 500, 500, 500, 500, 500, 500, 500, 500];


% Draw initial figure
g = figure;
g.Position = [150,50,1100,630];

set(gcf,'Renderer','OpenGL');
% Horizontal Runway
h = plot(rw_x,rw_y,'s','MarkerSize',180,'MarkerFaceColor','w','MarkerEdgeColor','w');
title('SMART TRAFFIC SIMULATION')

hold on
% Vertical Runway
h2 = plot(rw_x2,rw_y2,'s','MarkerSize',180,'MarkerFaceColor','w','MarkerEdgeColor','w');

hold on

% Create Traffic Lights
TL4= plot(380,695,'o','MarkerSize',10,'MarkerFaceColor','r','MarkerEdgeColor','k');
TL2= plot(615,305,'o','MarkerSize',10,'MarkerFaceColor','r','MarkerEdgeColor','k');
TL1= plot(380,305,'o','MarkerSize',10,'MarkerFaceColor','r','MarkerEdgeColor','k');
TL3= plot(615,695,'o','MarkerSize',10,'MarkerFaceColor','r','MarkerEdgeColor','k');
TL5= plot(363,695,'o','MarkerSize',10,'MarkerFaceColor','r','MarkerEdgeColor','k');
TL6= plot(633,305,'o','MarkerSize',10,'MarkerFaceColor','r','MarkerEdgeColor','k');
TL7= plot(380,275,'o','MarkerSize',10,'MarkerFaceColor','r','MarkerEdgeColor','k');
TL8= plot(615,723,'o','MarkerSize',10,'MarkerFaceColor','r','MarkerEdgeColor','k');

hold on

% Create Horizontal Runway lines
for k = 1:499
rl_x(k) = k * 2;
rl_y(k) = 500;
end

% Create Vertical Runway lines
for k = 1:199
rl_x2(k) = 500;
rl_y2(k) = k * 5;
end


% Horizontal Runway Line
rl1= plot(rl_x,rl_y,'s','MarkerSize',2,'MarkerFaceColor','k','MarkerEdgeColor','k');
rl1b= plot(rl_x-20,rl_y-90,'*','MarkerSize',1,'MarkerFaceColor','r','MarkerEdgeColor','r');
rl1c= plot(rl_x,rl_y+90,'*','MarkerSize',1,'MarkerFaceColor','r','MarkerEdgeColor','r');

% Vertical Runway Line
rl2= plot(rl_x2,rl_y2,'s','MarkerSize',2,'MarkerFaceColor','k','MarkerEdgeColor','k');
rl2b= plot(rl_x2+50,rl_y2,'*','MarkerSize',1,'MarkerFaceColor','r','MarkerEdgeColor','r');
rl2c= plot(rl_x2-50,rl_y2,'*','MarkerSize',1,'MarkerFaceColor','r','MarkerEdgeColor','r');


hold on
% Create Junction
h4 = plot(500,500,'s','MarkerSize',180,'MarkerFaceColor','k','MarkerEdgeColor','b');


% Create X-position for Cars
for k = 1:total_cars
   if wing(k)=='W'  
   h3(k) = plot(40,450,'s','MarkerSize',30,'MarkerFaceColor',color(k),'MarkerEdgeColor','k');
   elseif wing(k)=='S'
   h3(k) = plot(530,40,'s','MarkerSize',30,'MarkerFaceColor',color(k),'MarkerEdgeColor','k');
   elseif wing(k)=='E'
   h3(k) = plot(960,550,'s','MarkerSize',30,'MarkerFaceColor',color(k),'MarkerEdgeColor','k');
   elseif wing(k)=='N'
   h3(k) = plot(470,990,'s','MarkerSize',30,'MarkerFaceColor',color(k),'MarkerEdgeColor','k');
   elseif wing(k)=='w'
   h3(k) = plot(40,360,'s','MarkerSize',30,'MarkerFaceColor',color(k),'MarkerEdgeColor','k');
   elseif wing(k)=='s'
   h3(k) = plot(580,40,'s','MarkerSize',30,'MarkerFaceColor',color(k),'MarkerEdgeColor','k');
   elseif wing(k)=='e'
   h3(k) = plot(960,640,'s','MarkerSize',30,'MarkerFaceColor',color(k),'MarkerEdgeColor','k');
   elseif wing(k)=='n'
   h3(k) = plot(420,990,'s','MarkerSize',30,'MarkerFaceColor',color(k),'MarkerEdgeColor','k');
   end 
end

grid on
grid minor
ax = gca;
ax.GridColor = 'r';  % [R, G, B]
ax.Color=[0.5 0.5 0.5 0.3];
set(gca,'XTickLabel',[], 'YTickLabel', [])
set(h,'EraseMode','normal');
xlim([0,1000]);
ylim([0,1000]);

% Animation Loop
i = 1;



% Create X OR Y position for  Populated Cars
for k = 1:total_cars
    if wing(k) == 'W'
        x(k) = 40 * (0-k)*17;
    elseif wing(k) == 'S'
        x(k) = 40 * (10-k)*17;
    elseif wing(k) == 'E'
        x(k) = 40 * (37+(20-k))*7;
    elseif wing(k) == 'N'
       x(k) = 40 * (37+(30-k))*7;
    elseif wing(k) == 'w'
        x(k) = 40 * (40-k);
    elseif wing(k) == 's'
        x(k) = 40 * (50-k);
    elseif wing(k) == 'e'
        x(k) = 40 * (37+(60-k));
    elseif wing(k) == 'n'
        x(k) = 40 * (37+(70-k));
    end
end

% Create Speed for Cars
for k = 1:total_cars
if wing(k) == 'W'
    speed(k) = 40;
elseif wing(k) == 'S'
    speed(k) = 20;
elseif wing(k) == 'E'
    speed(k) = -40;    
elseif wing(k) == 'N'
    speed(k) = -20;
elseif wing(k) == 'w'
    speed(k) = 40;
elseif wing(k) == 's'
    speed(k) = 40;
elseif wing(k) == 'e'
    speed(k) = -40;
elseif wing(k) == 'n'
    speed(k) = -40;
end
end

%No. Of Queued Cars
queued_cars = 0;

%Simulation Progress
sim_progress = 0;

%No. Of Cars in Delay : W,S,E,N
delay_W = 0; delay_w = 0;
delay_S = 0; delay_s = 0;
delay_E = 0; delay_e = 0;
delay_N = 0; delay_n = 0;
delay_SUM = delay_W + delay_S + delay_E + delay_N + delay_w + delay_s + delay_e + delay_n;


% EMERGENCY DATA
p_lane = 'none';


cpttime = cputime;

ann1 = annotation('textbox', [0.75,0.82,0.1,0.1],...
           'String', delay_W + delay_w);
ann2 = annotation('textbox', [0.75,0.82,0.1,0.1],...
           'String', delay_N + delay_n);
ann3 = annotation('textbox', [0.75,0.82,0.1,0.1],...
           'String', delay_E + delay_e);
ann4 = annotation('textbox', [0.75,0.82,0.1,0.1],...
           'String', delay_S + delay_s);
ann = annotation('textbox', [0.75,0.82,0.1,0.1],...
           'String', 'TOTAL DELAYED CARS :');
ann_val = annotation('textbox', [0.75,0.82,0.1,0.1],...
           'String', delay_SUM);
sim = annotation('textbox', [0.65,0.72,0.1,0.1],...
           'String', 'SIMULATION PROGRESS (%) :');
time = annotation('textbox', [0.70,0.62,0.1,0.1],...
           'String', 'TIME TAKEN (secs) :');
sim_val = annotation('textbox', [0.85,0.72,0.1,0.1],...
           'String', sim_progress);
time_val = annotation('textbox', [0.84,0.62,0.1,0.1],...
           'String', cputime-cpttime);
emer = annotation('textbox', [0.64,0.12,0.1,0.1],...
           'String', 'CURRENT EMERGENCY LANE :');
emer_val = annotation('textbox', [0.84,0.12,0.1,0.1],...
           'String', p_lane);    
  

 
% CYCLE DATA
time_data = [];
total_delay_data = [];
sim_progress_data = [];
average_waiting_time_data=[];


       
       
% While loop
while i<=110000
    
    % Update locations
    for k = 1:total_cars
        if wing(k)=='W' || wing(k)=='A'
            set(h3(k),'XData',x(k));
            %get Current Car Position
            current_car_pos(k) = get(h3(k),'XData');
        elseif wing(k)=='S' || wing(k)=='B'
            set(h3(k),'YData',x(k));
            %get Current Car Position
            current_car_pos(k) = get(h3(k),'YData');
        elseif wing(k)=='E' || wing(k)=='C'
            set(h3(k),'XData',x(k));
            %get Current Car Position
            current_car_pos(k) = get(h3(k),'XData');
        elseif wing(k)=='N' || wing(k)=='D'
            set(h3(k),'YData',x(k));
            %get Current Car Position
            current_car_pos(k) = get(h3(k),'YData');
        elseif wing(k)=='w' || wing(k)=='a'
            set(h3(k),'XData',x(k));
            %get Current Car Position
            current_car_pos(k) = get(h3(k),'XData');
        elseif wing(k)=='s' || wing(k)=='b'
            set(h3(k),'YData',x(k));
            %get Current Car Position
            current_car_pos(k) = get(h3(k),'YData'); 
        elseif wing(k)=='e' || wing(k)=='c'
            set(h3(k),'XData',x(k));
            %get Current Car Position
            current_car_pos(k) = get(h3(k),'XData'); 
        elseif wing(k)=='n' || wing(k)=='d'
            set(h3(k),'YData',x(k));
            %get Current Car Position
            current_car_pos(k) = get(h3(k),'YData');
        end 
    end
    
  
    % Draw On Screen
    drawnow;
    
    % Advance Car locations for each car
    
    for k = 1:total_cars
        
           if wing(k)=='W'
               next_pos = current_car_pos(k)+speed(k);
               
               if k == 1 || k == 11 || k == 21 || k == 31
                   if next_pos < 365 || next_pos > 645; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if (next_pos < current_car_pos(k-1)-40) && next_pos < 365 || next_pos > 645; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
               elseif wing(k)=='A'
               next_pos = current_car_pos(k)+speed(k);
               
               if k == 1 || k == 11 || k == 21 || k == 31
                   if next_pos < 365 || next_pos > 645; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if (next_pos < current_car_pos(k-1)-40) && next_pos < 365 || next_pos > 645; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
           elseif wing(k)=='w'
               next_pos = current_car_pos(k)+speed(k);
               
               if k == 41 || k == 51 || k == 61 || k == 71
                   if next_pos < 365 || next_pos > 645; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if (next_pos < current_car_pos(k-1)-40) && next_pos < 365 || next_pos > 645; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
             elseif wing(k)=='a'
               next_pos = current_car_pos(k)+speed(k);
               
               if k == 41 || k == 51 || k == 61 || k == 71
                   if next_pos < 365 || next_pos > 645; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if (next_pos < current_car_pos(k-1)-40) && next_pos < 365 || next_pos > 645; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
           elseif wing(k)=='S'
               next_pos = current_car_pos(k)+speed(k);
               if k == 1 || k == 11 || k == 21 || k == 31
                   if next_pos < 315 || next_pos > 595; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if (next_pos < current_car_pos(k-1)-80) && next_pos < 315 || next_pos > 595; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
               elseif wing(k)=='B'
               next_pos = current_car_pos(k)+speed(k);
               if k == 1 || k == 11 || k == 21 || k == 31
                   if next_pos < 315 || next_pos > 595; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if (next_pos < current_car_pos(k-1)-80) && next_pos < 315 || next_pos > 595; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
           elseif wing(k)=='s'
               next_pos = current_car_pos(k)+speed(k);
               if k == 41 || k == 51 || k == 61 || k == 71
                   if next_pos < 315 || next_pos > 595; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if (next_pos < current_car_pos(k-1)-80) && next_pos < 315 || next_pos > 595; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
            elseif wing(k)=='b'
               next_pos = current_car_pos(k)+speed(k);
               if k == 41 || k == 51 || k == 61 || k == 71
                   if next_pos < 315 || next_pos > 595; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if (next_pos < current_car_pos(k-1)-80) && next_pos < 315 || next_pos > 595; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
           elseif wing(k)=='E'
               next_pos = current_car_pos(k)+speed(k);
               if k == 1 || k == 11 || k == 21 || k == 31
                   if next_pos > 635 || next_pos < 355; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if (next_pos > current_car_pos(k-1)+40) && next_pos > 635 || next_pos < 355; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
               elseif wing(k)=='C'
               next_pos = current_car_pos(k)+speed(k);
               if k == 1 || k == 11 || k == 21 || k == 31
                   if next_pos > 635 || next_pos < 355; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if (next_pos > current_car_pos(k-1)+40) && next_pos > 635 || next_pos < 355; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
           elseif wing(k)=='e'
               next_pos = current_car_pos(k)+speed(k);
               if k == 41 || k == 51 || k == 61 || k == 71
                   if next_pos > 635 || next_pos < 355; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if (next_pos > current_car_pos(k-1)+40) && next_pos > 635 || next_pos < 355; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
             elseif wing(k)=='c'
               next_pos = current_car_pos(k)+speed(k);
               if k == 41 || k == 51 || k == 61 || k == 71
                   if next_pos > 635 || next_pos < 355; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if (next_pos > current_car_pos(k-1)+40) && next_pos > 635 || next_pos < 355; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
           elseif wing(k)=='N'
               next_pos = current_car_pos(k)+speed(k);
               if k == 1 || k == 11 || k == 21 || k == 31
                   if next_pos > 685 || next_pos < 405; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if (next_pos > current_car_pos(k-1)+80) && next_pos > 685 || next_pos < 405; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
               elseif wing(k)=='D'
               next_pos = current_car_pos(k)+speed(k);
               if k == 1 || k == 11 || k == 21 || k == 31
                   if next_pos > 685 || next_pos < 405; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if (next_pos > current_car_pos(k-1)+80) && next_pos > 685 || next_pos < 405; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
           elseif wing(k)=='n'
               next_pos = current_car_pos(k)+speed(k);
               if k == 41 || k == 51 || k == 61 || k == 71
                   if next_pos > 685 || next_pos < 405; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if (next_pos > current_car_pos(k-1)+80) && next_pos > 685 || next_pos < 405; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
             elseif wing(k)=='d'
               next_pos = current_car_pos(k)+speed(k);
               if k == 41 || k == 51 || k == 61 || k == 71
                   if next_pos > 685 || next_pos < 405; 
                       x(k) = x(k) + speed(k); 
                   end
               else
                   if (next_pos > current_car_pos(k-1)+80) && next_pos > 685 || next_pos < 405; 
                       x(k) = x(k) + speed(k); 
                   end
               end
               
           end
           
           
           %%%%%%%% EMERGENCY ALGORITHM 
           
           % Check for emergency car
           if wing(k)=='S'
               if current_car_pos(k)<= 375 &&  current_car_pos(k)> -1;
                   if p_lane == 'none'; 
                       if color(k) == 'r';
                           p_lane = wing(k);
                       end 
                   end
               end
           end  
           
           if wing(k)=='E'
               if current_car_pos(k)>= 575 && current_car_pos(k)< 1001;
                   if p_lane == 'none' ; 
                       if color(k) == 'r';
                           p_lane = wing(k);
                       end 
                   end
               end
           end
           
           if wing(k)=='N'
               if current_car_pos(k)>= 625 &&  current_car_pos(k)< 1001;
                   if p_lane == 'none' ; 
                       if color(k) == 'r';
                           p_lane = wing(k);
                       end 
                   end
               end    
           end
           
           if wing(k)=='W'
               if current_car_pos(k)<= 425 &&  current_car_pos(k)> -1;
                   if p_lane == 'none' ; 
                       if color(k) == 'r';
                           p_lane = wing(k);
                       end 
                   end
               end    
           end
           
           
           %%%%%%%% JUNCTION ALGORITHM
 
           next_pos = current_car_pos(k)+speed(k);
           if wing(k)=='W'
           if next_pos >= 365; 
               if queued_cars == 0; 
                   
                   if p_lane == wing(k); x(k) = x(k) + 5; queued_cars = 1;set(TL1,'MarkerfaceColor','g');queued_car = k;end
               elseif queued_cars == 1 && queued_car == k; x(k) = x(k) + 5;
                end 
           end
           if next_pos > 645; 
               queued_cars = 0;set(TL1,'MarkerfaceColor','r');sim_progress = sim_progress + 1; if color(k)=='r'; p_lane = 'none';end  
           end
           
           %For curved crossings
           if curved(k) == 1 && curvable(k) == 1;
           if next_pos > 565; wing(k) = 'B';speed(k) = 40;curvable(k) = 0;end
           end
           end
           
           if wing(k)=='w'
           if next_pos >= 365; 
              x(k) = x(k) + 5;set(TL7,'MarkerfaceColor','g');
           end
           if next_pos > 645; 
               set(TL7,'MarkerfaceColor','r');sim_progress = sim_progress + 1;  
           end
           
           %For curved crossings
           if curved(k) == 2 && curvable(k) == 1;
           if next_pos > 450; wing(k) = 'd';speed(k) = -40;x(k) = x(k) - 120;curvable(k) = 0;set(TL7,'MarkerfaceColor','r');end
           end
           end
           
           if wing(k)=='A'
           if next_pos >= 365; 
              x(k) = x(k) + 5;set(TL7,'MarkerfaceColor','g');
           end
           if next_pos > 645; 
               set(TL7,'MarkerfaceColor','r');queued_cars = 0;sim_progress = sim_progress + 1; if color(k)=='r'; p_lane = 'none';end
           end
           end
           
           if wing(k)=='a'
           if next_pos > 645; 
               sim_progress = sim_progress + 1;  
           end
           end
           
           if wing(k)=='S'   
           if next_pos >= 315; 
               if queued_cars == 0;
                   if p_lane == 'none'; x(k) = x(k) + 5; queued_cars = 1;set(TL2,'MarkerfaceColor','g');queued_car = k; end
                    if p_lane == wing(k); x(k) = x(k) + 5; queued_cars = 1;set(TL2,'MarkerfaceColor','g');queued_car = k; end
               elseif queued_cars == 1 && queued_car == k; x(k) = x(k) + 5;
               end 
           end
           if next_pos > 595; 
               queued_cars = 0;set(TL2,'MarkerfaceColor','r');sim_progress = sim_progress + 1;if color(k)=='r'; p_lane = 'none';end
           end
           
           %For curved crossings
           if curved(k) == 1 && curvable(k) == 1;
           if next_pos > 575; wing(k) = 'C';speed(k) = -40;x(k) = x(k) - 120;curvable(k) = 0;set(TL2,'MarkerfaceColor','r');end
           end
           end
           
           if wing(k)=='s'
           if next_pos >= 315; 
               x(k) = x(k) + 5; set(TL6,'MarkerfaceColor','g'); 
           end
           if next_pos > 595; 
               set(TL6,'MarkerfaceColor','r');sim_progress = sim_progress + 1;
           end
           
           %For curved crossings
           if curved(k) == 2 && curvable(k) == 1;
           if next_pos > 395; wing(k) = 'a';speed(k) = 40;x(k) = x(k) + 250;curvable(k) = 0; set(TL6,'MarkerfaceColor','r');end
           end
           end
           
           if wing(k)=='B'
           if next_pos >= 315; 
               x(k) = x(k) + 5; set(TL6,'MarkerfaceColor','g'); 
           end
           if next_pos > 595; 
               set(TL6,'MarkerfaceColor','r');queued_cars = 0;sim_progress = sim_progress + 1; if color(k)=='r'; p_lane = 'none';end
           end
           end
           
           if wing(k)=='b'
           if next_pos > 595; 
               sim_progress = sim_progress + 1;
           end
           end
           
           if wing(k)=='E'
           if next_pos <= 635; 
               if queued_cars == 0; 
                   if p_lane == 'none';x(k) = x(k) - 5; queued_cars = 1;set(TL3,'MarkerfaceColor','g');queued_car = k;end
                   if p_lane == wing(k);x(k) = x(k) - 5; queued_cars = 1;set(TL3,'MarkerfaceColor','g');queued_car = k;end
               elseif queued_cars == 1 && queued_car == k; x(k) = x(k) - 5;
               end 
           end
           if next_pos < 355; 
               queued_cars = 0;set(TL3,'MarkerfaceColor','r'); sim_progress = sim_progress + 1;if color(k)=='r'; p_lane = 'none';end
           end
           
           %For curved crossings
           if curved(k) == 1 && curvable(k) == 1;
           if next_pos < 435; wing(k) = 'D';speed(k) = -40;curvable(k) = 0;set(TL3,'MarkerfaceColor','r');end
           end
           end
           
           if wing(k)=='e'
           if next_pos <= 635; 
             x(k) = x(k) - 5;set(TL8,'MarkerfaceColor','g');
           end
           if next_pos < 355; 
               set(TL8,'MarkerfaceColor','r'); sim_progress = sim_progress + 1;
           end
           
           %For curved crossings
           if curved(k) == 2 && curvable(k) == 1;
           if next_pos < 550; wing(k) = 'b';speed(k) = 40;x(k) = x(k) + 120;curvable(k) = 0;set(TL8,'MarkerfaceColor','r');end
           end
           end
           
           if wing(k)=='C'
           if next_pos <= 635; 
             x(k) = x(k) - 5;set(TL8,'MarkerfaceColor','g');
           end
           if next_pos < 355; 
               set(TL8,'MarkerfaceColor','r'); queued_cars = 0; sim_progress = sim_progress + 1;if color(k)=='r'; p_lane = 'none';end
           end
           end
           
           if wing(k)=='c'
           if next_pos < 355; 
               sim_progress = sim_progress + 1;
           end
           end
           
           if wing(k)=='N'
           if next_pos <= 685; 
               if queued_cars == 0; 
                   if p_lane == 'none';x(k) = x(k) - 5; queued_cars = 1;set(TL4,'MarkerfaceColor','g');queued_car = k;end
                   if p_lane == wing(k);x(k) = x(k) - 5; queued_cars = 1;set(TL4,'MarkerfaceColor','g');queued_car = k;end
               elseif queued_cars == 1 && queued_car == k; x(k) = x(k) - 5;
               end 
           end
           if next_pos < 405; 
               queued_cars = 0;set(TL4,'MarkerfaceColor','r'); sim_progress = sim_progress + 1; if color(k)=='r'; p_lane = 'none';end
           end
           
           %For curved crossings
           if curved(k) == 1 && curvable(k) == 1;
           if next_pos < 420; wing(k) = 'A';speed(k) = 40;x(k) = x(k) + 60;curvable(k) = 0;set(TL4,'MarkerfaceColor','r');end
           end
           end
           
           if wing(k)=='n'
           if next_pos <= 685; 
              x(k) = x(k) - 5;set(TL5,'MarkerfaceColor','g'); 
           end
           if next_pos < 405; 
               set(TL5,'MarkerfaceColor','r'); sim_progress = sim_progress + 1;
           end
           
           %For curved crossings
           if curved(k) == 2 && curvable(k) == 1;
           if next_pos < 605; wing(k) = 'c';speed(k) = -40;x(k) = x(k) - 250;curvable(k) = 0;set(TL5,'MarkerfaceColor','r');end
           end
           end
           
           if wing(k)=='D'
           if next_pos <= 685; 
              x(k) = x(k) - 5;set(TL5,'MarkerfaceColor','g'); 
           end
           if next_pos < 405; 
               set(TL5,'MarkerfaceColor','r');queued_cars = 0;sim_progress = sim_progress + 1;if color(k)=='r'; p_lane = 'none';end
           end
           end
           
           if wing(k)=='d'
           if next_pos < 405; 
                sim_progress = sim_progress + 1;
           end
           end
           
           
           
    end
    
     delay_W = 0; delay_w = 0;
     delay_N = 0; delay_n = 0;
     delay_E = 0; delay_e = 0;
     delay_S = 0; delay_s = 0;
     
    % Check number of delayed cars
     for k = 1:total_cars
           if wing(k)=='W'
               if current_car_pos(k)<= 425 &&  current_car_pos(k)> -1; delay_W=delay_W+1; end
           end
           if wing(k)=='w'
               if current_car_pos(k)<= 425 &&  current_car_pos(k)> -1; delay_w=delay_w+1; end
           end
           if wing(k)=='N'
               if current_car_pos(k)>= 625 && current_car_pos(k)< 1001; delay_N=delay_N+1; end
           end 
           if wing(k)=='n'
               if current_car_pos(k)>= 625 && current_car_pos(k)< 1001; delay_n=delay_n+1; end
           end 
           if wing(k)=='E'
               if current_car_pos(k)>= 575 && current_car_pos(k)< 1001; delay_E=delay_E+1; end
           end
           if wing(k)=='e'
               if current_car_pos(k)>= 575 && current_car_pos(k)< 1001; delay_e=delay_e+1; end
           end
           if wing(k)=='S'
               if current_car_pos(k)<= 375 &&  current_car_pos(k)> -1; delay_S=delay_S+1; end
           end 
           if wing(k)=='s'
               if current_car_pos(k)<= 375 &&  current_car_pos(k)> -1; delay_s=delay_s+1; end
           end 
     end
     
     delay_SUM = delay_W + delay_S + delay_E + delay_N + delay_w + delay_s + delay_e + delay_n;

     
     
    clmo(ann1)
    ann1 = annotation('textbox', [0.64,0.62,0.1,0.1],...
           'String', delay_E + delay_e);
    clmo(ann2)
    ann2 = annotation('textbox', [0.37,0.62,0.1,0.1],...
           'String', delay_N + delay_n);
    clmo(ann3)
    ann3 = annotation('textbox', [0.37,0.26,0.1,0.1],...
           'String', delay_W + delay_w);
    clmo(ann4)
    ann4 = annotation('textbox', [0.64,0.26,0.1,0.1],...
           'String', delay_S + delay_s);
    clmo(ann)
    ann = annotation('textbox', [0.65,0.82,0.1,0.1],...
           'String', 'TOTAL DELAYED CARS :');
    clmo(ann_val)
    ann_val = annotation('textbox', [0.85,0.82,0.1,0.1],...
           'String', delay_SUM);
    clmo(sim)
    sim = annotation('textbox', [0.65,0.72,0.1,0.1],...
           'String', 'SIMULATION PROGRESS (%) :');
    clmo(time)
    time = annotation('textbox', [0.70,0.62,0.1,0.1],...
           'String', 'TIME TAKEN (secs) :');
    clmo(sim_val)
    sim_val = annotation('textbox', [0.85,0.72,0.1,0.1],...
           'String', sim_progress/200);
    clmo(time_val)
    time_val = annotation('textbox', [0.84,0.62,0.1,0.1],...
           'String', cputime-cpttime);
    clmo(emer)
    emer = annotation('textbox', [0.64,0.12,0.1,0.1],...
           'String', 'CURRENT EMERGENCY LANE :');
    clmo(emer_val)
     emer_val = annotation('textbox', [0.84,0.12,0.1,0.1],...
           'String', p_lane);   

    
    % COLLECT CYCLE DATA
    time_data = [time_data; cputime-cpttime];
    total_delay_data = [total_delay_data; delay_SUM];
    sim_progress_data = [sim_progress_data; sim_progress/200];
    average_waiting_time = (time_data(end) - time_data(1)) / (total_delay_data(end) - total_delay_data(1));
    average_flow_rate_pm = (total_delay_data(end) - total_delay_data(1)) / (time_data(end) - time_data(1))*60;
    average_waiting_time_data = [average_waiting_time_data, average_waiting_time] ;
    
    
    
       
    % ---------------------------------------------------------------------
    
    if sim_progress >= 20000; 
           
    x = [time_data, sim_progress_data];
    y = total_delay_data;
    trnData = [x y];
    numMFs = 5;
    mfType = 'gauss2mf';
    epoch_n = 40;
    in_fis = genfis1(trnData,numMFs,mfType);
    out_fis = anfis(trnData,in_fis,40);    
    
    figure
    outplot1 = plot(time_data,total_delay_data); 
    title('DELAY PLOT AGAINST TIME');
    ylabel('AVERAGE DELAY') 
    xlabel('SIMULATION TIME') 
    figure
    outplot2 = plot(time_data,average_waiting_time_data); 
    title('AVERAGE WAITING TIME PLOT AGAINST TIME ');
    ylabel('AVERAGE WAITING TIME') 
    xlabel('SIMULATION TIME') 
    figure
    gensurf(out_fis);
    title('SURFACE PLOT OF INPUT VARIABLES');
    figure
    plot(0,0);
    title('PERFORMANCE EVALUATION METRICS');
    set(gca,'YTick',[]); set(gca,'XTick',[]);
    ann = annotation('textbox', [0.15,0.80,0.1,0.1],...
           'String', 'TOTAL SIMULATED CARS :');
    ann_val = annotation('textbox', [0.55,0.80,0.1,0.1],...
           'String', total_cars);
    ann2 = annotation('textbox', [0.15,0.70,0.1,0.1],...
           'String', 'TOTAL TIME TAKEN :');
    ann2_val = annotation('textbox', [0.55,0.70,0.1,0.1],...
           'String', time_data(end));
    ann3 = annotation('textbox', [0.15,0.60,0.1,0.1],...
           'String', 'AVERAGE WAITING TIME :');
    ann3_val = annotation('textbox', [0.55,0.60,0.1,0.1],...
           'String', average_waiting_time);
    ann4 = annotation('textbox', [0.15,0.50,0.1,0.1],...
           'String', 'AVERAGE FLOW RATE PER MINUTE :');
    ann4_val = annotation('textbox', [0.65,0.50,0.1,0.1],...
           'String', average_flow_rate_pm);
      
    finish;    
    end
    
   
    
    % Update iterations
    i = i+1;
   
    
    
end